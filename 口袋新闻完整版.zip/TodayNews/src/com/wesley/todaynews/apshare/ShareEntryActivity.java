package com.wesley.todaynews.apshare;

import cn.sharesdk.alipay.share.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity{

}
