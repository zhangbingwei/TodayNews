package com.wesley.todaynews.utils;

import android.app.Activity;

/**
 * 界面进入进出动画
 * 
 * @author zhangbingwei
 * 
 */
public class ActivityAnimation {

	public static void setActivityAnimation(Activity activity) {
		activity.overridePendingTransition(android.R.anim.fade_in,
				android.R.anim.fade_out);
	}

}
