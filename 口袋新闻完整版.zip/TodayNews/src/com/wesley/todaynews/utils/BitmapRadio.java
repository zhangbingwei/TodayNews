package com.wesley.todaynews.utils;

import android.content.Context;
import android.graphics.BitmapFactory;

/**
 * 获取图片宽高比率
 * 
 * @author zhangbingwei
 * 
 */
public class BitmapRadio {
	public static float getBitmapRatio(Context context, int resourceId) {
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(context.getResources(), resourceId,
				options);
		return options.outHeight / (float) options.outWidth;
	}
}
