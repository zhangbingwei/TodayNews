package com.wesley.todaynews.utils;

import android.content.Context;

import com.lidroid.xutils.BitmapUtils;

public class BitmapHelper {

	private BitmapHelper() {
	}

	private static BitmapUtils bitmapUtils;

	public static BitmapUtils getBitmapUtils(Context context) {
		if (bitmapUtils == null) {
			bitmapUtils = new BitmapUtils(context);
			// 第一个参数：上下文，第二个参数：缓存路径，第三个参数：最多消耗多少比例的内存(0.3f,0.5f)
			// bitmapUtils = new BitmapUtils(context, diskCachePath,
			// memoryCacheSize);
		}
		return bitmapUtils;
	}

}
