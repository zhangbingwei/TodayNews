package com.wesley.todaynews.pager;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.os.SystemClock;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.etsy.android.grid.StaggeredGridView;
import com.etsy.android.grid.util.DynamicHeightImageView;
import com.google.gson.Gson;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.squareup.picasso.Picasso;
import com.wesley.todaynews.R;
import com.wesley.todaynews.activity.PhotosDetailActivity;
import com.wesley.todaynews.domain.PhotosData;
import com.wesley.todaynews.domain.PhotosData.TabPhotos;
import com.wesley.todaynews.utils.ActivityAnimation;
import com.wesley.todaynews.utils.BitmapHelper;
import com.wesley.todaynews.utils.CacheUtils;
import com.wesley.todaynews.utils.ToastUtils;
import com.wesley.todaynews.view.PullToRefreshStaggeredGridView;

public class PhotosPager extends BasePager implements
		OnRefreshListener<StaggeredGridView> {

	private View photosView;// View对象
	private PullToRefreshStaggeredGridView gvPhotos;// GridView瀑布流
	private StaggeredGridView gridView;

	private String photosURL;
	private ArrayList<TabPhotos> photosList;// 数据列表集合

	private int currentPage;// 当前第几页
	private int totalSize;// 总共的页数

	public PhotosPager(Activity activity) {
		super(activity);
	}

	@Override
	public View initViews() {
		photosView = View.inflate(mActivity, R.layout.activity_photos, null);
		gvPhotos = (PullToRefreshStaggeredGridView) photosView
				.findViewById(R.id.gv_photos);
//		gvPhotos.setMode(Mode.PULL_FROM_START);
		gvPhotos.setMode(Mode.BOTH);
		gvPhotos.setOnRefreshListener(this);
		gridView = gvPhotos.getRefreshableView();

		return photosView;
	}

	// 初始化页签数据
	@Override
	public void initData() {
		photosURL = "http://apicloud.mob.com/wx/article/search?page=1&cid=24&key=14f82f5af6040&size=30";

		// 首先从缓存获取数据，减少用户的等待时间
		String cache = CacheUtils.getCache(photosURL, mActivity);
		if (!TextUtils.isEmpty(cache)) {
			parseData(cache, false, false);
		}

		getDataFromServer();

		// GridView的点击事件
		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Intent intent = new Intent(mActivity,
						PhotosDetailActivity.class);
				intent.putExtra("photosURL", photosList.get(position).sourceUrl);
				mActivity.startActivity(intent);
				ActivityAnimation.setActivityAnimation(mActivity);
			}
		});

	}

	@Override
	public void onRefresh(PullToRefreshBase<StaggeredGridView> refreshView) {
		// 下拉刷新
		if (refreshView.isHeaderShown()) {
			// 显示下拉刷新时间
			String label = DateUtils.formatDateTime(mActivity,
					System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME
							| DateUtils.FORMAT_SHOW_DATE
							| DateUtils.FORMAT_ABBREV_ALL);
			refreshView.getLoadingLayoutProxy().setLastUpdatedLabel(label);

			// 这里写下拉刷新的任务
			String pullDownUrl = "http://apicloud.mob.com/wx/article/search?"
					+ "page=" + (++currentPage)
					+ "&cid=24&key=14f82f5af6040&size=20";
			// System.out.println("下拉刷新：当前是第几页呢：：：" + currentPage +
			// ",总共的页数是："
			// + totalPage);
			if (currentPage <= totalSize) {
				getMoreDataFromServer(pullDownUrl, true);
			} else {
				noDataSleep();
			}
		} else {// 上拉加载
			// 显示上拉加载时间
			String label = DateUtils.formatDateTime(mActivity,
					System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME
							| DateUtils.FORMAT_SHOW_DATE
							| DateUtils.FORMAT_ABBREV_ALL);
			refreshView.getLoadingLayoutProxy().setLastUpdatedLabel(label);

			// 这里写上拉加载更多的任务
			String pullUpUrl = "http://apicloud.mob.com/wx/article/search?"
					+ "page=" + (++currentPage)
					+ "&cid=24&key=14f82f5af6040&size=20";
			// System.out.println("上拉加载：当前是第几页呢：：：" + currentPage +
			// ",总共的页数是："
			// + totalPage);
			if (currentPage <= totalSize) {
				getMoreDataFromServer(pullUpUrl, false);
			} else {
				noDataSleep();
			}

		}
	}

	// 当下拉刷新或者上拉加载没有更多数据的时候休眠
	public void noDataSleep() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				SystemClock.sleep(3000);
			}
		});
		gvPhotos.onRefreshComplete();
	}

	/**
	 * 从网络根据url获取数据
	 */
	public void getDataFromServer() {
		HttpUtils utils = new HttpUtils();
		utils.send(HttpMethod.GET, photosURL, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				String result = responseInfo.result;
				parseData(result, false, false);

				// 从服务器获取json后，设置缓存
				CacheUtils.setCache(photosURL, result, mActivity);

			}

			public void onFailure(
					com.lidroid.xutils.exception.HttpException error,
					String arg1) {
				ToastUtils.showToast(mActivity, "获取网络数据失败，请检查网络");
				error.printStackTrace();
			}
		});
	}

	public void getMoreDataFromServer(String moreUrl, boolean isPullDown) {
		final boolean mIsPullDown = isPullDown;

		HttpUtils utils = new HttpUtils();
		utils.send(HttpMethod.GET, moreUrl, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				String result = responseInfo.result;
				parseData(result, true, mIsPullDown);

				// 从服务器获取json后，设置缓存
				CacheUtils.setCache(photosURL, result, mActivity);
			}

			@Override
			public void onFailure(
					com.lidroid.xutils.exception.HttpException error, String msg) {
				ToastUtils.showToast(mActivity, "获取网络数据失败，请检查网络");
				error.printStackTrace();
			}
		});
	}

	protected void parseData(String result, boolean isMore, boolean isPullDown) {
		Gson gson = new Gson();
		PhotosData data = gson.fromJson(result, PhotosData.class);

		if (!isMore) {
			currentPage = data.result.curPage;
			totalSize = data.result.total;
			System.out.println("当前的页数：" + currentPage);
			System.out.println("总页数：" + totalSize);
			photosList = data.result.list;
		} else {
			// if (list == null) {
			// list = new ArrayList<NewsData.Data>();
			// }
			// 如果是下拉刷新，则将新增加的数据加到ListView的头部
			if (isPullDown) {
				List<TabPhotos> pullDownList = data.result.list;
				currentPage = data.result.curPage;
				System.out.println("下拉以后的页数：" + currentPage);
				photosList.addAll(0, pullDownList);
				adapter.notifyDataSetChanged();
				gvPhotos.onRefreshComplete();
			} else {
				// 如果是上拉加载，则将新增加的数据添加到ListView的底部
				List<TabPhotos> pullUpList = data.result.list;
				currentPage = data.result.curPage;
				System.out.println("上拉的页数：" + currentPage);
				photosList.addAll(pullUpList);
				adapter.notifyDataSetChanged();
				gvPhotos.onRefreshComplete();
			}
		}

		if (photosList != null) {
			adapter = new photosAdapter();
			gridView.setAdapter(adapter);
		}

	}

	private static final SparseArray<Double> sPositionHeightRatios = new SparseArray<Double>();
	private Random mRandom;
	private photosAdapter adapter;

	/**
	 * 页签新闻列表适配器
	 * 
	 * @author zhangbingwei
	 * 
	 */
	class photosAdapter extends BaseAdapter {
		private BitmapUtils bitmap;

		// 在适配器初始化的时候给他设置默认的图片
		public photosAdapter() {
			mRandom = new Random();
			bitmap = BitmapHelper.getBitmapUtils(mActivity);
			bitmap.configDefaultLoadFailedImage(R.drawable.news_pic_default);// 加载失败显示图片
			bitmap.configDefaultLoadingImage(R.drawable.news_pic_default);// 加载中显示图片
		}

		@Override
		public int getCount() {
			return photosList.size();
		}

		@Override
		public TabPhotos getItem(int position) {
			return photosList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = View.inflate(mActivity, R.layout.item_tab_photos,
						null);
				holder = new ViewHolder();
				holder.ivPhoto = (DynamicHeightImageView) convertView
						.findViewById(R.id.iv_photo);
				holder.tvTitle = (TextView) convertView
						.findViewById(R.id.tv_title);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			double positionHeight = getPositionRatio(position);
			holder.ivPhoto.setHeightRatio(positionHeight);

			TabPhotos item = getItem(position);
//			holder.ivPhoto.setTag(item.thumbnails);// 把url设置给ivPhoto做标签，这样防止加载的时候图片错位

			holder.tvTitle.setText(item.title);
			// holder.tvTime.setText(item.pubTime);
			if (!TextUtils.isEmpty(item.thumbnails)) {
//				if (holder.ivPhoto.getTag().equals(item.thumbnails)) {
					String itemUrl = item.thumbnails.split("\\$")[0];
//					bitmap.display(holder.ivPhoto, itemUrl);
					Picasso.with(mActivity).load(itemUrl).error(R.drawable.news_pic_default).into(holder.ivPhoto);
//				}
			}

			return convertView;
		}

	}

	static class ViewHolder {
		DynamicHeightImageView ivPhoto;
		TextView tvTitle;
		// TextView tvTime;
	}

	private double getPositionRatio(final int position) {
		double ratio = sPositionHeightRatios.get(position, 0.0);
		if (ratio == 0) {
			ratio = getRandomHeightRatio();
			sPositionHeightRatios.append(position, ratio);
		}
		return ratio;
	}

	private double getRandomHeightRatio() {
		return (mRandom.nextDouble() / 2.0) + 1.0; // height will be 1.0 - 1.5
													// the width
	}

}
