package com.wesley.todaynews.activity;

import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.AbsoluteLayout;
import android.widget.AbsoluteLayout.LayoutParams;
import android.widget.EditText;
import android.widget.TextView;

import com.wesley.todaynews.R;
import com.wesley.todaynews.utils.ActivityAnimation;

/**
 * 新闻搜索页面
 * 
 * @author zhangbingwei
 * 
 */
public class NewsSearchFirstActivity extends Activity {
	ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

	AbsoluteLayout myLayout;
	AbsoluteLayout myLayoutTwo;
	GestureDetector detector;

	EditText etContent;

	int indexPage = 0;
	int screenWidth;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_search_first_news);
		findView();
		init();
	}

	private void findView() {
		myLayout = (AbsoluteLayout) findViewById(R.id.myLayout);
		myLayoutTwo = (AbsoluteLayout) findViewById(R.id.myLayoutTwo);
		etContent = (EditText) findViewById(R.id.et_content);
	}

	// 初始化页面内容
	private void init() {
		// detector = new GestureDetector(this, new MyGestureListener());
		detector = new GestureDetector(this, new SimpleOnGestureListener() {
			@Override
			public boolean onFling(MotionEvent e1, MotionEvent e2, float moveX,
					float moveY) {
				etContent.setText("");
				if (e1.getX() < e2.getX()) {// 从左向右滑动
					indexPage++;
					if (indexPage == data.size()) {
						indexPage = 0;
					}

					switch (myLayout.getVisibility()) {
					case 0:// myLayout处于显示状态,本身要放大并且消失,myLayoutTwo要放大并且显示
						scaleCancer(myLayout, 1000, 0);
						myLayout.setVisibility(View.GONE);

						setDataToPage(myLayoutTwo, indexPage);
						scaleIn(myLayoutTwo, 2000, 0);
						myLayoutTwo.setVisibility(View.VISIBLE);
						break;
					case 4:// 处于不可见状态
					case 8:// 处于消失状态

						scaleCancer(myLayoutTwo, 1000, 0);
						myLayoutTwo.setVisibility(View.GONE);

						setDataToPage(myLayout, indexPage);
						scaleIn(myLayout, 2000, 0);
						myLayout.setVisibility(View.VISIBLE);
						break;

					}
				}
				return false;
			}
		});

		screenWidth = getWindowManager().getDefaultDisplay().getWidth();

		// DisplayMetrics metrics = new DisplayMetrics();
		// getWindowManager().getDefaultDisplay().getMetrics(metrics);
		// screenWidth = metrics.widthPixels;
		initData();
		setDataToPage(myLayout, indexPage);
	}

	// 放大并显示的动画
	protected void scaleIn(AbsoluteLayout myLayout, int time, int delayTime) {
		ScaleAnimation animation = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f,
				Animation.RELATIVE_TO_PARENT, 0.5f,
				Animation.RELATIVE_TO_PARENT, 0.5f);
		animation.setStartOffset(delayTime);
		animation.setDuration(time);

		AlphaAnimation animation2 = new AlphaAnimation(0.0f, 1.0f);
		animation2.setDuration(time);

		AnimationSet animationSet = new AnimationSet(true);
		animationSet.addAnimation(animation);
		animationSet.addAnimation(animation2);

		myLayout.startAnimation(animationSet);
	}

	// 放大并消失的动画
	private void scaleCancer(AbsoluteLayout myLayout, int time, int delayTime) {
		ScaleAnimation animation = new ScaleAnimation(1.0f, 1.5f, 1.0f, 1.5f,
				Animation.RELATIVE_TO_PARENT, 0.5f,
				Animation.RELATIVE_TO_PARENT, 0.5f);
		animation.setStartOffset(delayTime);
		animation.setDuration(time);

		AlphaAnimation animation2 = new AlphaAnimation(1.0f, 0.0f);
		animation2.setDuration(time);

		AnimationSet animationSet = new AnimationSet(true);
		animationSet.addAnimation(animation);
		animationSet.addAnimation(animation2);

		myLayout.startAnimation(animationSet);
	};

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return detector.onTouchEvent(event);
	}

	// 初始化数据
	private void initData() {
		for (int i = 0; i < 2; i++) {
			switch (i) {
			case 0:
				ArrayList<String> newData = new ArrayList<String>();
				String[] newsFirst = { "中国", "美国", "菲律宾", "南海", "东盟", "韩国",
						"萨德", "俄罗斯", "奥运会", "巴西", "越南", "钓鱼岛", "日本", "印度", "朝核" };
				for (int j = 0; j < newsFirst.length; j++) {
					newData.add(newsFirst[j]);
				}
				data.add(newData);
				break;
			case 1:
				String[] newsSecond = { "人民币", "小米", "百度", "乐视", "阿里巴巴",
						"农村淘宝", "GDP", "苹果", "腾讯", "京东", "网购", "习近平", "经济改革",
						"滴滴", "专车" };
				ArrayList<String> newData1 = new ArrayList<String>();
				for (int j = 0; j < newsSecond.length; j++) {
					newData1.add(newsSecond[j]);
				}
				data.add(newData1);
				break;
			}
		}
	}

	// 给页面添加数据
	private void setDataToPage(AbsoluteLayout myLayout, int indexPage) {
		myLayout.removeAllViewsInLayout();
		int startY = 50;
		for (int i = 0; i < data.get(indexPage).size(); i++) {
			int x = get(100, screenWidth - 200);
			int y = startY;
			final TextView textView = new TextView(this);
			textView.setTextSize(16);
			textView.setTextColor(setColor());
			textView.setText(data.get(indexPage).get(i));
			AbsoluteLayout.LayoutParams layoutParams = new LayoutParams(
					LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, x, y);
			myLayout.addView(textView, layoutParams);

			textView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					etContent.setText(textView.getText().toString());

					Intent intent = new Intent(NewsSearchFirstActivity.this,
							NewsSearchActivity.class);
					intent.putExtra("content", etContent.getText().toString());
					startActivity(intent);
					ActivityAnimation
							.setActivityAnimation(NewsSearchFirstActivity.this);
				}
			});

			startY += 100;
		}
	}

	private int setColor() {
		// 随机颜色
		Random random = new Random();
		int ranColor = 0xff000000 | random.nextInt(0x00ffffff);
		return ranColor;
	}

	// 随机生成一个min到max之间的随机数
	private int get(int min, int max) {
		return new Random().nextInt(max) % (max - min + 1) + min;
	}

	@Override
	protected void onStart() {
		super.onStart();
		etContent.setText("");
	}

}
