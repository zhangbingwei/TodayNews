package com.wesley.todaynews.activity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.wesley.todaynews.R;
import com.wesley.todaynews.domain.Person;
import com.wesley.todaynews.utils.HaoHanAdapter;
import com.wesley.todaynews.utils.PhoneContactsUtils;
import com.wesley.todaynews.utils.ToastUtils;
import com.wesley.todaynews.view.QuickIndexBar;
import com.wesley.todaynews.view.QuickIndexBar.OnLetterUpdateListener;

public class FriendsFindActivity extends Activity implements
		OnItemLongClickListener {

	private ListView mMainList;
	private ArrayList<Person> persons;
	private TextView tv_center;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_find_friends);

		QuickIndexBar bar = (QuickIndexBar) findViewById(R.id.bar);
		// 设置监听
		bar.setListener(new OnLetterUpdateListener() {
			@Override
			public void onLetterUpdate(String letter) {
				showLetter(letter);
				// 根据字母定位ListView, 找到集合中第一个以letter为拼音首字母的对象,得到索引
				for (int i = 0; i < persons.size(); i++) {
					Person person = persons.get(i);
					String l = person.getPinyin().charAt(0) + "";
					if (TextUtils.equals(letter, l)) {
						// 匹配成功
						mMainList.setSelection(i);
						break;
					}
				}
			}

			@Override
			public void onFinished() {
				tv_center.setVisibility(View.GONE);
			}
		});

		mMainList = (ListView) findViewById(R.id.lv_main);

		persons = new ArrayList<Person>();

		// 填充数据 , 排序
		fillAndSortData(persons);

		mMainList.setAdapter(new HaoHanAdapter(FriendsFindActivity.this,
				persons));

		tv_center = (TextView) findViewById(R.id.tv_center);


		mMainList.setOnItemLongClickListener(this);

	}

	/**
	 * 显示字母
	 */
	protected void showLetter(String letter) {
		tv_center.setVisibility(View.VISIBLE);
		tv_center.setText(letter);

	}

	private void fillAndSortData(ArrayList<Person> persons) {
		List<String> nameList = PhoneContactsUtils.getContactsName(this);
		int size = nameList.size();
		// 填充数据
		for (int i = 0; i < size; i++) {
			String name = nameList.get(i);
			persons.add(new Person(name));
		}

		// 进行排序
		Collections.sort(persons);
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			int position, long id) {
		ToastUtils.showToast(FriendsFindActivity.this, persons.get(position).getName());
		
		return true;
	}

}
