/** Automatically generated file. DO NOT MODIFY */
package com.wesley.todaynews;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}